﻿using System;
using System.ComponentModel;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using System.Windows.Media;

namespace LED_Controller.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private Color _selectedColor = Colors.White;
        public Color SelectedColor
        {
            get => _selectedColor;
            set
            {
                if (_selectedColor != value)
                {
                    _selectedColor = value;
                    OnPropertyChanged();
                }
            }
        }

        public ICommand SendColorCommand { get; }

        public MainViewModel()
        {
            SendColorCommand = new RelayCommand(SendColor);
        }

        private void SendColor()
        {
            byte r = SelectedColor.R;
            byte g = SelectedColor.G;
            byte b = SelectedColor.B;

            byte[] data = new byte[] { r, g, b };

            using (UdpClient client = new UdpClient())
            {
                client.Send(data, data.Length, "192.168.0.123", 4210); // IP & Port des ESP anpassen

            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
