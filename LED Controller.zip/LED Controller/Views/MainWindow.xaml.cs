using System.Windows;
using System.Windows.Media;

namespace LED_Controller.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OnSendColor(object sender, RoutedEventArgs e)
        {
            // Dummy-Funktion – UDP folgt später
            MessageBox.Show("Farbe senden!");
        }
    }
}