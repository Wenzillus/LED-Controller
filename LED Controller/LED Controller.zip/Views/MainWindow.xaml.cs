using System.Windows;
using System.Windows.Media;
using LED_Controller.ViewModels;

namespace LED_Controller.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainViewModel();
        }

        private void OnSendColor(object sender, RoutedEventArgs e)
        {
            // Dummy-Funktion – UDP folgt später
            MessageBox.Show("Farbe senden!");
        }
    }
}